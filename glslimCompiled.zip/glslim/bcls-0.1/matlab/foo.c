/* Dummy c main program.  Only needed to convince Matlab's mex script
   to keep going. */
int main(void) {};
